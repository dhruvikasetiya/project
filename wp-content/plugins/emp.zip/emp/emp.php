<?php

//Plugin Name: Emp
//Plugin URI:https://in.linkedin.com/in/dipaknarola
//Description: A simple wordpress plugin
//Author: Dhruvi Kasetiya
//Author URI: https://in.linkedin.com/in/dipaknarola
//version:1.0

register_activation_hook(__FILE__,'form_data_activate');
register_deactivation_hook(__FILE__,'form_data_deactivate');

function form_data_activate(){
    global $wpdb;
    global $table_prefix;
    $table=$table_prefix.'emp';
    
    $sql="CREATE TABLE $table (
        `id` int(11) NOT NULL primary key,
        `name` varchar(50) NOT NULL,
        `email` varchar (50) NOT NULL)
         ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
         $wpdb->query($sql);

    $sql2="insert into $table(`id`,`name`,`email`) values(1,'mansi','m@gmail.com')";
    $wpdb->query($sql2);

    // $data = array(
    //     'name' => 'dhruvi',
    //     'email'=> 'dhulu@gmail.com'
    // );

    // $wpdb->insert($emp,$data);
}
function form_data_deactivate(){
    global $wpdb;
    global $table_prefix;
    $table=$table_prefix.'emp';
    $sql="DROP TABLE $table";
     $wpdb->query($sql);

    $sql = "TRUNCATE ` $emp`";
    $wpdb->query($sql);

}

function myshortcode($atts){
    $atts= array_change_key_case($atts);

    $atts = shortcode_atts(array(
        'msg'=> 'I am good ',
        'note'=> 'defalut',
        'type'=> 'img_gallery'
    ), $atts);

    ob_start();
    ?>
        <h1>hello youtube</h1>
    <?php
    $html = ob_get_clean();

    // return 'results:'.$atts['msg'].''.$atts['note'];
    return $html;
    include $atts['type'].'.php';
}
add_shortcode('tube','myshortcode');

?>