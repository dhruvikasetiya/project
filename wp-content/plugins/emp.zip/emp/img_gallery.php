<img src="http://localhost/theme/wp-content/uploads/2022/07/d1.jpg" alt="" srcset="">
<img src="http://localhost/theme/wp-content/uploads/2022/07/d1.jpg" alt="" srcset="">