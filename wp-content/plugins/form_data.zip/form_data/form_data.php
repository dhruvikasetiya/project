<?php

//Plugin Name: Form Data
//Plugin URI:https://in.linkedin.com/in/dipaknarola
//Description: A simple wordpress plugin
//Author: Dhruvi Kasetiya
//Author URI: https://in.linkedin.com/in/dipaknarola
//version:1.0


register_activation_hook(__FILE__,'form_data_activate');
register_deactivation_hook(__FILE__,'form_data_deactivate');


// $filedata = get_file_data(plugin_dir_path(__FILE__) . '\form_data\data.php', array(
//   'Page Name' => 'data.php',
  
//  // 'Template File' => 'template-data.php',));
//   print_r($filedata) );


require_once __DIR__ . '/data.php';

  function tbare_wordpress_plugin_demo($atts) {
    $Content = "<style>\r\n";
    $Content .= "h3.demoClass {\r\n";
    $Content .= "color: #26b158;\r\n";
    $Content .= "}\r\n";
    $Content .= "</style>\r\n";
    $Content .= '<h3 class="demoClass">Check it out!</h3>';
     
      return $Content;

     
  }
  add_shortcode('tbare-plugin-demo', 'tbare_wordpress_plugin_demo');

















































  // function form_data_activate(){
//     global $wpdb;
//     global $table_prefix;
//     $table=$table_prefix.'form_data';
//     $sql = "CREATE TABLE $table (
//         `id` int(11) NOT NULL,
//         `name` varchar(200) NOT NULL
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
//       ALTER TABLE $table
//     ADD PRIMARY KEY (`id`);
//       MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;";

//       $wpdb->query($sql);
// }


// function form_data_deactivate(){
//     //"DROP TABLE `theme`.`form_data`"
//     global $wpdb;
//     global $table_prefix;
//     $table=$table_prefix.'form_data';
//     $sql = "  DROP TABLE  `theme`.$table";
//     $wpdb->query($sql);
// }
?>
